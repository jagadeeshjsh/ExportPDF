import { Component } from '@angular/core';

import * as jspdf from '../../lib/jspdf.min';
import html2canvas from 'html2canvas';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'JSPDF13052019';
data: any;
  constructor() {
    this.data = {
      labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
      datasets: [
        {
          label: 'First Dataset',
          data: [65, 59, 80, 81, 56, 55, 40]
        },
        {
          label: 'Second Dataset',
          data: [28, 48, 40, 19, 86, 27, 90]
        }
      ]
    };
  }

  isPriviewHidden: boolean = true;

  public setFlag() {
    this.isPriviewHidden = false;
  }

  capture2() {
    var data = document.getElementById('contentToConvert');
    html2canvas(data).then(canvas => {


      // var imgWidth = 210;
      // var pageHeight = 295;
      // var imgHeight = canvas.height * imgWidth / canvas.width;
      // var heightLeft = imgHeight;



      var doc = new jspdf('p', 'mm', 'a4');
      var imgWidth = doc.internal.pageSize.getWidth() - 15;
      var pageHeight = doc.internal.pageSize.getHeight() - 15;
      var imgHeight = canvas.height * imgWidth / canvas.width;
      var heightLeft = imgHeight;

      doc.setProperties({
        title: 'Jsh PDF Title',
        subject: 'Report for data',
        author: 'Jagadeesh',
        keywords: 'generated, javascript, web 2.0, ajax',
        creator: 'MEEE'
      });

      doc.text('hello', 10, 150, 10);

      var position = 20;
      const contentDataURL = canvas.toDataURL('image/png');

      doc.addImage(contentDataURL, 'PNG', 10, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        console.log("position....", position)
        doc.addPage();
        doc.addImage(contentDataURL, 'PNG', 10, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      var pageCount = doc.internal.getNumberOfPages();
      for (let i = 0; i < pageCount; i++) {
        doc.setPage(i);
        //    doc.text(100, 8, doc.internal.getCurrentPageInfo().pageNumber + "/" + pageCount);
        doc.line(0, 15, doc.internal.pageSize.getWidth(), 15); // horizontal line  
        doc.setDrawColor(255, 0, 0); // draw red lines  
        doc.line(0, doc.internal.pageSize.getHeight() - 15, doc.internal.pageSize.getWidth(), doc.internal.pageSize.getHeight() - 15);
        var str = "Page " + doc.internal.getCurrentPageInfo().pageNumber + " of " + pageCount;
        doc.setFontSize(10);// optional
        doc.text(str, 100, doc.internal.pageSize.height - 10);
      }
      doc.save('file.pdf');
      
    });
  }
}
